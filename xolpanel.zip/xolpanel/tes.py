@bot.on(events.NewMessage(pattern="/start"))
async def menu(event):
	inline = [
[Button.url("< ADMIN PANEL >>","menu")],
[Button.url("[ TELEGRAM ]","https://t.me/lynz_anak_soleh_rajin_menabung"),
Button.url("[ CHANNEL ]","https://t.me/xlynzcnfg")],

		msg = f"""
** 🔥 WELCOME TO SSHXVPN 🔥 **
"""
await event.reply(msg,buttons=inline)